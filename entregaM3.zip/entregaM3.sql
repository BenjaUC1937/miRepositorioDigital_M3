/*Crear Base de datos*/
CREATE SCHEMA IF NOT EXISTS `Alke_Wallet` DEFAULT CHARACTER SET utf8mb4;
USE Alke_Wallet;

/*Crea la tabla de usuarios*/
CREATE TABLE IF NOT EXISTS usuarios (
  user_id INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  contrasegna VARCHAR(12) NOT NULL,
  saldo DECIMAL(10,2) NOT NULL,
  fechaCreacion TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Crea la tabla de transaccion*/
CREATE TABLE IF NOT EXISTS transaccion (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_user_id INT,
    receiver_user_id INT,
    currency_id INT,
    importe DECIMAL(10,2) NOT NULL,
    transaction_date DATETIME,
    FOREIGN KEY (sender_user_id) REFERENCES usuarios(user_id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_user_id) REFERENCES usuarios(user_id) ON DELETE CASCADE,
    FOREIGN KEY (currency_id) REFERENCES currency(currency_id) ON DELETE CASCADE
);
/*Crea la tabla de currency*/
CREATE TABLE IF NOT EXISTS currency (
currency_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
currency_name VARCHAR(50) NOT NULL,
currency_symbol VARCHAR(10) NOT NULL
);

/*Insertar datos en la tabla usuarios*/
INSERT INTO usuarios (user_id,nombre, apellido, email, contrasegna, saldo) VALUES 
    ('1','Juan', 'Perez', 'juanp@gmail.com', 'contrasenajp06', 71000.00),
    ('2','Maria', 'Garcia', 'mariagarcia07@hotmail.com', 'clavemg07', 55050.50),
    ('3','Facundo', 'Rosales', 'frosales@gmail.com', 'contrasenafr08', 98500.00),
    ('4','Bruno', 'Sepulveda', 'bsepu@gmail.com', 'clavebs09', 8500.00),
    ('5','Martina', 'Pedrero', 'mpdre12@hotmail.com', 'contrasenamp10', 9625.00),
    ('6','Daniel', 'Lorca', 'lorca.daniel@egmail.com', 'claveld11', 4157.60),
	('7','Tamara', 'Mallorca', 'tammallo@hotmail.com', 'clavetm12', 8500.00),
    ('8','Martin', 'Rosales', 'mrosales21@gmail.com', 'contrasenamr13', 340000.00),
    ('9','Constanza', 'Solar', 'csolar71@gmail.com', 'clavecs14', 15007.00),
    ('10','Evaluna', 'Roncati', 'evaluti41@hotmail.com', 'contrasenaer15', 31000.00),
    ('11','Nicolas', 'Moreno', 'nicmoreno@egmail.com', 'clavenm16', 50000.00),
    ('12', 'Josefa', 'Pedrero', 'jpedrero96@hotmail.com','pedrero17', 90000.00),
    ('13', 'Clarivel', 'Jeldres', 'clarijel@gmail.com', 'clari123', 6238000.23);


/*Insertar datos en la tabla transaccion*/
INSERT INTO transaccion (sender_user_id, receiver_user_id, currency_id, transaction_id, importe, transaction_date) VALUES
	('1', '13', '5', '1', '210000', CURRENT_TIMESTAMP),
    ('2', '12', '4', '2', '350050', CURRENT_TIMESTAMP),
    ('3', '11', '3', '3', '89000', CURRENT_TIMESTAMP),
    ('4', '10', '2', '4', '100000', CURRENT_TIMESTAMP),
    ('5', '9', '1', '5', '450825', CURRENT_TIMESTAMP),
    ('6', '8', '2', '6', '247000', CURRENT_TIMESTAMP);
    
    SELECT * FROM transaccion;
    SELECT * FROM currency;
    SELECT * FROM usuarios;
    
    /*Insertar datos en la tabla currency*/
    INSERT INTO currency (currency_id, currency_name, currency_symbol) VALUE
    ('1', 'Dólar estadounidense','US$'),
    ('2', 'Euro', '€'),
    ('3', 'Libra esterlina','£'),
    ('4', 'Yen japónes','¥'),
    ('5', 'Peso chileno', '$');



/*Querys*/
/*Consulta todas las transacciones de un usuario especifico*/
SELECT nombre AS usuario,
    currency_name AS moneda
FROM usuarios
    INNER JOIN transaccion t ON t.sender_user_id = usuarios.user_id
    INNER JOIN currency c ON c.currency_id = t.currency_id
WHERE user_id = 5;

/*Consulta para obtener el nombre de la moneda elegida por un usuario específico*/
-- SELECT * FROM alke_wallet.currency

SELECT nombre AS usuario,
    currency_name AS moneda
FROM usuarios
    INNER JOIN transaccion t ON t.sender_user_id = usuarios.user_id
    INNER JOIN currency c ON c.currency_id = t.currency_id
WHERE user_id = 4;

/* Consulta para obtener todas las transacciones registradas*/
SELECT t.transaction_id,
       u1.nombre AS emisor,
       u2.nombre AS receptor,
       c.currency_name AS moneda,
       t.importe AS monto,
       t.transaction_date AS fecha
FROM transaccion t
INNER JOIN usuarios u1 ON t.sender_user_id = u1.user_id
INNER JOIN usuarios u2 ON t.receiver_user_id = u2.user_id
INNER JOIN currency c ON t.currency_id = c.currency_id;

/*Sentencia DML para modificar el campo correo electrónico de un usuario específico*/
UPDATE usuarios
SET email = 'jpedrero96@hotmail.com'
WHERE user_id = 12;

/*Sentencia para eliminar los datos de una transacción (eliminado de la fila completa)*/
DELETE FROM transaccion
WHERE transaction_id = 3;
